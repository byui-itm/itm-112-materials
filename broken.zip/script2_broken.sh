#!/bin/bash

FAVORITE_COLOR = 'yellow'

read -p "What is my favorite color? "GUESS

if [ $FAVORITE_COLOR = $GUESS]; then
    echo "You guessed it!"
else
    echo "You do not know my favorite color, for shame"
done

echo "Thank you for playing 💪🏼"
