#!/bin/bash

read -p "Please enter your name: " NAME
read -p "Please enter your birthday: "

echo "Hello NAME, your birthday is $BIRTHDAY"