#!/bin/bash

while true
do
    read -p "Enter an absolute path to a folder on your computer, q to exit, c to clear: "

    if [ "$REPLY" = "q"]; then
        break
    else if ["$REPLY" = "c" ]; then
        clear
        continue

    echo "Listing contents of $REPLY"
    ls $REPLY

done